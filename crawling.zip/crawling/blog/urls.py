from django.contrib import admin
from django.conf.urls import include, url
from . import views
#contain all functions and html
urlpatterns = [
    url('about$',views.about,name="about"),   
    #url('saveTest$',views.saveTest,name="saveTest"),   
    url('showTest$',views.showTest,name="showTest"), 
    url('saveTest1$',views.saveTest1,name="saveTest1"),
    url('savetest2$',views.savetest2,name="savetest2"),
    #url('savetest$',views.savetest,name="savetest"),
    url('flipkart$',views.flipkart,name="flipkart"), 
    url('search$',views.search,name="search"),
    url('firstpage$',views.firstpage,name="firstpage"),
    url('contact$',views.contact,name="contact"), 
    url('signup$',views.signup,name="signup"),
    url('showcrawldata$',views.showcrawldata,name="showcrawldata"),
    url('login$',views.login,name="login"),
    url('barchart$',views.barchart,name="barchart"),
    url('trap$',views.trap,name="trap"),
    
    
    url('home$',views.home,name="home"),
    url('',views.index,name="index"), # landing / default page 
    
]

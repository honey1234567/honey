import mysql.connector
from bs4 import BeautifulSoup as soup 
import requests
import pandas
from urllib2 import urlopen as ureq


def saveData(e,p):
        
        c = mysql.connector.connect(user="root",password="root",host="localhost",database="industrial")

        cr = c.cursor()
        #cr.execute("insert into emp(name,email,pwd) values('"+n+"','"+e+"','"+p+"')")
        st ="insert into customer(email,psw) values('"+e+"','"+p+"')"
        cr.execute(st)
     
        
        c.commit()
        #c.close()
'''
def checkData(e,p):
        
        c = mysql.connector.connect(user="root",password="root",host="localhost",database="industrial")

        cr = c.cursor()
        #cr.execute("insert into emp(name,email,pwd) values('"+n+"','"+e+"','"+p+"')")
        
     
        cr.execute("select * from customer where email='"+e+"'")
        res = cr.fetchall()
        d=[]
        for r in res:
                a=[]
                a.append(r[0])
                
        d.append(a)

        return d        
        #cr.execute("select * from emp where name='"+n+"' and email='"+e+"' ")
        c.commit()
        #c.close()
'''
def showTest(e,p):
        c = mysql.connector.connect(user="root",password="root",host="localhost",database="industrial")
        cr = c.cursor()
       
        cr.execute("select * from customer where email='"+e+"' and psw='"+p+"' ")
        res = cr.fetchall()
        d=[]
        a=[]
        for r in res:
                
                a.append(r[0])
                #a.append(r[1])
                
        d.append(a)

        return d  
                
def savecrawldata(name):
        c = mysql.connector.connect(user="root",password="root",host="localhost",database="industrial")
        c1= mysql.connector.connect(user="root",password="root",host="localhost",database="industrial")
        cr = c.cursor()
        cr1 = c1.cursor()
        cr.execute("delete from crawl")
        cr1.execute("delete from crawl2")
        myurl='https://www.flipkart.com/search?q=iphones&marketplace=FLIPKART&otracker=start&as-show=on&as=off&page=2'
        uclient=ureq(myurl)
        pagehtml=uclient.read()
        uclient.close()
        pagesoup=soup(pagehtml,"html.parser")
        containers=pagesoup.findAll("div",{"class":"_3O0U0u"})
        container=containers[0]
        count=0
        for container in containers:
                count=count+1
                price=container.findAll("div",{"class":"col col-5-12 _2o7WAb"})
                arr=[]
                for string in price[0].stripped_strings:
                        arr.append(repr(string))#if container in place of price[0] then it shows ratings also
                       
                p1=list(arr)
                word5=p1[0].split('u\'\\u20b9')
                price_new=word5[1].replace('\'',' ')
                prod_rat=container.findAll("span",{"class":"_2_KrJI"})
                rat=[]
                for string in prod_rat[0].stripped_strings:
                        rat.append(repr(string))#if container in place of price[0] then it shows ratings also
                        #print(repr(string))
                r1=list(rat)
                
                word_rat=r1[0].split('u\'')
                
                w_rat=word_rat[1].split('R')
                rev=container.findAll("span",{"class":"_38sUEc"})  
                rev1=list(rev)
                rev_arr=[]
                for string in rev1[0].stripped_strings:
                        rev_arr.append(repr(string))#if container in place of price[0] then it shows ratings also
                w2=rev_arr[0].split('u\'')
                w2_rat=w2[1].split('R')
                rat_new1=w2_rat[0].replace(',','')
                w3=rev_arr[2].split('u\'')
                w_rev=w3[1].split('R')
                ftrs=container.findAll("ul",{"class":"vFw0gD"}) 
                
                ftrs_arr=[]
                for string in ftrs[0].stripped_strings:#doubt in ftrs[0]***********************************************************
                        ftrs_arr.append(repr(string))#if container in place of price[0] then it shows ratings also
                
                
                ftrs_list=list(ftrs_arr)
                
                
                for i in range(0,len(ftrs_arr)):
                        word=ftrs_list[i].split('u\'')
                        w_f=word[1].replace('\'',' ')
                        ft="insert into crawl2(id,features) values('"+container.div.img["alt"]+"','"+w_f+"')"
                        cr1.execute(ft)
                        c1.commit()
                st ="insert into crawl(name,price,rating,reviews) values('"+container.div.img["alt"]+"','"+price_new+"','"+ rat_new1+"','"+w_rev[0]+"')"
                cr.execute(st)
                c.commit()
        cr.execute("select * from crawl where name='"+name+"'")
        cr1.execute("select * from crawl2 where id='"+name+"'")
        res = cr.fetchall()
        res1=cr1.fetchall()
        d=[]
        a=[]
        for r in res:
                #a=[]
                a.append(r[0])
                a.append(r[1])
                a.append(r[2])
                a.append(r[3])
        d.append(a)

        return d 
        
def showanalyzedata():
        c = mysql.connector.connect(user="root",password="root",host="localhost",database="industrial")
        c1= mysql.connector.connect(user="root",password="root",host="localhost",database="industrial")
        cr = c.cursor()
        cr1 = c1.cursor()
        cr.execute("delete from crawl")
        cr1.execute("delete from crawl2")
        myurl='https://www.flipkart.com/search?q=iphones&marketplace=FLIPKART&otracker=start&as-show=on&as=off&page=2'
        uclient=ureq(myurl)
        pagehtml=uclient.read()
        uclient.close()
        pagesoup=soup(pagehtml,"html.parser")
        containers=pagesoup.findAll("div",{"class":"_3O0U0u"})
        container=containers[0]
        count=0
        for container in containers:
                count=count+1
                price=container.findAll("div",{"class":"col col-5-12 _2o7WAb"})
                arr=[]
                for string in price[0].stripped_strings:
                        arr.append(repr(string))#if container in place of price[0] then it shows ratings also
                       
                p1=list(arr)
                word5=p1[0].split('u\'\\u20b9')
  
           
            
                price_new=word5[1].replace('\'',' ')
                w8=price_new.split(',')
                prr=w8[0]+w8[1]
                prod_rat=container.findAll("span",{"class":"_2_KrJI"})
                rat=[]
                for string in prod_rat[0].stripped_strings:
                        rat.append(repr(string))#if container in place of price[0] then it shows ratings also
                        #print(repr(string))
                r1=list(rat)
                
                word_rat=r1[0].split('u\'')
                
                w_rat=word_rat[1].split('R')
                #rat_new1=w2_rat[0].replace(',','')
                rev=container.findAll("span",{"class":"_38sUEc"})  
                rev1=list(rev)
                rev_arr=[]
                for string in rev1[0].stripped_strings:
                        rev_arr.append(repr(string))#if container in place of price[0] then it shows ratings also
                w2=rev_arr[0].split('u\'')
                w2_rat=w2[1].split('R')
                rat_new1=w2_rat[0].replace(',','')
                w3=rev_arr[2].split('u\'')
                w_rev=w3[1].split('R')
                ftrs=container.findAll("ul",{"class":"vFw0gD"}) 
                
                ftrs_arr=[]
                for string in ftrs[0].stripped_strings:#doubt in ftrs[0]***********************************************************
                        ftrs_arr.append(repr(string))#if container in place of price[0] then it shows ratings also
                
                
                ftrs_list=list(ftrs_arr)
                
                
                for i in range(0,len(ftrs_arr)):
                        word=ftrs_list[i].split('u\'')
                        w_f=word[1].replace('\'',' ')
                        ft="insert into crawl2(id,features) values('"+container.div.img["alt"]+"','"+w_f+"')"
                        cr1.execute(ft)
                        c1.commit()
                st ="insert into crawl(name,price,rating,reviews) values('"+container.div.img["alt"]+"','"+prr+"','"+ rat_new1+"','"+w_rev[0]+"')"
                cr.execute(st)
                c.commit()
        cr.execute("select * from crawl where price in(select min(price) from crawl)")
        res = cr.fetchall()
        #res1=cr1.fetchall()
        d=[]
        a=[]
        for r in res:
                #a=[]
                a.append(r[0])
                a.append(r[1])
                a.append(r[2])
                a.append(r[3])
        d.append(a)

        return d 
'''
        for r1 in res1:
                a.append(r1[1])        
        d.append(a)

        return d  
'''
                
def rating():
        c = mysql.connector.connect(user="root",password="root",host="localhost",database="industrial")
        c1= mysql.connector.connect(user="root",password="root",host="localhost",database="industrial")
        cr = c.cursor()
        cr1 = c1.cursor()
        cr.execute("delete from crawl")
        cr1.execute("delete from crawl2")
        myurl='https://www.flipkart.com/search?q=iphones&marketplace=FLIPKART&otracker=start&as-show=on&as=off&page=2'
        uclient=ureq(myurl)
        pagehtml=uclient.read()
        uclient.close()
        pagesoup=soup(pagehtml,"html.parser")
        containers=pagesoup.findAll("div",{"class":"_3O0U0u"})
        container=containers[0]
        count=0
        for container in containers:
                count=count+1
                price=container.findAll("div",{"class":"col col-5-12 _2o7WAb"})
                arr=[]
                for string in price[0].stripped_strings:
                        arr.append(repr(string))#if container in place of price[0] then it shows ratings also
                       
                p1=list(arr)
                word5=p1[0].split('u\'\\u20b9')
                #print word5
           
            
                price_new=word5[1].replace('\'',' ')
                w8=price_new.split(',')
                prr=w8[0]+w8[1]
                prod_rat=container.findAll("span",{"class":"_2_KrJI"})
                rat=[]
                for string in prod_rat[0].stripped_strings:
                        rat.append(repr(string))#if container in place of price[0] then it shows ratings also
                        #print(repr(string))
                r1=list(rat)
                
                word_rat=r1[0].split('u\'')
                
                w_rat=word_rat[1].split('R')
                rev=container.findAll("span",{"class":"_38sUEc"})  
                rev1=list(rev)
                rev_arr=[]
                for string in rev1[0].stripped_strings:
                        rev_arr.append(repr(string))#if container in place of price[0] then it shows ratings also
                w2=rev_arr[0].split('u\'')
                w2_rat=w2[1].split('R')#APPLY REGEX IN THISpython manage.py runserver
                rat_new1=w2_rat[0].replace(',','')
                
                w3=rev_arr[2].split('u\'')
                w_rev=w3[1].split('R')
                ftrs=container.findAll("ul",{"class":"vFw0gD"}) 
                
                ftrs_arr=[]
                for string in ftrs[0].stripped_strings:#doubt in ftrs[0]***********************************************************
                        ftrs_arr.append(repr(string))#if container in place of price[0] then it shows ratings also
                
                
                ftrs_list=list(ftrs_arr)
                
                
                for i in range(0,len(ftrs_arr)):
                        word=ftrs_list[i].split('u\'')
                        w_f=word[1].replace('\'',' ')
                        ft="insert into crawl2(id,features) values('"+container.div.img["alt"]+"','"+w_f+"')"
                        cr1.execute(ft)
                        c1.commit()
                st ="insert into crawl(name,price,rating,reviews) values('"+container.div.img["alt"]+"','"+prr+"','"+rat_new1+"','"+w_rev[0]+"')"
                cr.execute(st)
                c.commit()
        cr.execute("select * from crawl where rating = (select max(rating) from crawl)")
        res = cr.fetchall()
        #res1=cr1.fetchall()
        d=[]
        a=[]
        for r in res:
                #a=[]
                a.append(r[0])
                a.append(r[1])
                a.append(r[2])
                a.append(r[3])
        d.append(a)
        return d